/* suruculer tablosuna surucu eklendiğinde çalışacak olan stored procedure */
CREATE OR REPLACE PROCEDURE surucu_ekle_procedure(
    p_surucuad VARCHAR,
    p_surucusoyad VARCHAR,
    p_surucutel VARCHAR
)
AS
$$
BEGIN
    INSERT INTO suruculer (surucuad, surucusoyad, surucutel)
    VALUES (p_surucuad, p_surucusoyad, p_surucutel);

    -- Bilgilendirme mesajı gönderiyoruz --
    RAISE NOTICE 'Sürücü başarıyla eklendi.';
END;
$$
LANGUAGE plpgsql;


/* suruculer tablosundaki bir satırı güncellemek için procedure */
CREATE OR REPLACE PROCEDURE surucu_guncelle_procedure(
    p_surucuid INTEGER,
    p_surucuad VARCHAR DEFAULT NULL,
    p_surucusoyad VARCHAR DEFAULT NULL,
    p_surucutel VARCHAR DEFAULT NULL
)
AS
$$
BEGIN
    UPDATE suruculer SET 
		surucuad = COALESCE(p_surucuad, surucuad),
        surucusoyad = COALESCE(p_surucusoyad, surucusoyad),
        surucutel = COALESCE(p_surucutel, surucutel)
    WHERE surucuid = p_surucuid;

    -- Güncelleme mesajı gönderiyoruz --
    RAISE NOTICE 'Sürücü ID: % başarıyla güncellendi.', p_surucuid;
END;
$$
LANGUAGE plpgsql;


/* suruculer tablosundan bir kayıt silmek için prosedür */
CREATE OR REPLACE PROCEDURE surucu_sil_procedure(
    p_surucuid INTEGER
)
AS
$$
BEGIN
    DELETE FROM suruculer WHERE surucuid = p_surucuid;

    -- Silme mesajı gönderiyoruz --
    RAISE NOTICE 'Sürücü ID: % başarıyla silindi.', p_surucuid;
END;
$$
LANGUAGE plpgsql;

