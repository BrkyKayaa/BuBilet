/* biletler_ucak tablosundaki PNR_ucak değeri için sequence */
CREATE SEQUENCE pnr_ucak_sequence START 1 INCREMENT 1 MINVALUE 1 MAXVALUE 999999;

/* pnr_ucak değerini otomatik belirleyecek fonksiyonu tanımlıyoruz */
CREATE OR REPLACE FUNCTION generate_pnr_ucak() RETURNS TRIGGER
AS
$$
BEGIN
	NEW.pnr_ucak := 'PNR-PT' || LPAD(NEXTVAL('pnr_ucak_sequence')::TEXT, 6, '0');
	RETURN NEW;
END;
$$
LANGUAGE plpgsql;

/* biletler_ucak tablosuna yeni veri eklendiğinde çalışacak trigger'i tanımlıyoruz. */
CREATE TRIGGER pnr_ucak_trigger BEFORE INSERT ON biletler_ucak FOR EACH ROW 
WHEN (NEW.pnr_ucak IS NULL)
	EXECUTE FUNCTION generate_pnr_ucak();


/* biletler_ucak tablosuna veri eklendiğinde seferler_ucak tablosundaki alinabilirkoltuksayisi
sütununun değerini 1 azaltan fonksiyon */
CREATE OR REPLACE FUNCTION update_alinabilirkoltuksayisi_seferler_ucak() RETURNS TRIGGER
AS
$$
BEGIN
	UPDATE seferler_ucak SET alinabilirkoltuksayisi = alinabilirkoltuksayisi - 1
	WHERE ucakseferno = NEW.ucakseferno;

	RETURN NEW;
END;
$$
LANGUAGE plpgsql;

CREATE TRIGGER update_seferler_ucak_Trigger AFTER INSERT ON biletler_ucak
FOR EACH ROW EXECUTE FUNCTION update_alinabilirkoltuksayisi_seferler_ucak();


/* biletler_ucak tablosuna veri eklemeye yarayan prosedür */
CREATE OR REPLACE PROCEDURE insert_bilet_ucak(
    IN p_kullaniciid INTEGER,
    IN p_ucakseferno VARCHAR,
    IN p_satistarihi DATE,
    IN p_yolcuad VARCHAR,
    IN p_yolcusoyad VARCHAR,
    IN p_yolcutelefon VARCHAR
)
AS 
$$
DECLARE
    v_alinabilir_koltuk INTEGER;
    v_son_koltuk INTEGER;
BEGIN
    -- Seferdeki kalan alınabilir koltuk sayısına bakıyoruz
    SELECT alinabilirkoltuksayisi INTO v_alinabilir_koltuk FROM seferler_ucak WHERE ucakseferno = p_ucakseferno;

    -- Eğer alınabilir koltuk sayısı 0 ise işlem yapmayacak ve bir exception fırlatacak
    IF v_alinabilir_koltuk <= 0 THEN
        RAISE EXCEPTION 'Bu uçuş için boş koltuk bulunmamaktadır, bilet alınamaz.';
    END IF;

    -- Bu sefer için en son eklenen koltuk numarasını buluyoruz ki yeni eklenecek koltuğun numarasını bulalım
    SELECT COALESCE(MAX(koltukno), 0)
    INTO v_son_koltuk
    FROM biletler_ucak
    WHERE ucakseferno = p_ucakseferno;

    -- Yeni koltuk numarasını hesaplayan kodlar
    v_son_koltuk := v_son_koltuk + 1;

    -- bileti ekleyen kodlar
    INSERT INTO biletler_ucak (kullaniciid, ucakseferno, koltukno, satistarihi, yolcuad, yolcusoyad, yolcutelefon)
    VALUES (p_kullaniciid, p_ucakseferno, v_son_koltuk, p_satistarihi, p_yolcuad, p_yolcusoyad, p_yolcutelefon);

    RAISE NOTICE 'Bilet başarıyla alındı! Koltuk No: %', v_son_koltuk;
END;
$$ 
LANGUAGE plpgsql;


/* Yukarıda tanımladığım prosedür .NET sürümü ve Npgsql kütüphanesinin sürümlerinin uyumsuzluğundan dolayı
doğru çalıştırılamıyor dolayısı ile tekrardan fonksiyon olarak tanımlıyorum */
CREATE OR REPLACE FUNCTION insert_bilet_ucak_function(
    p_kullaniciid INTEGER,
    p_ucakseferno VARCHAR,
    p_satistarihi TIMESTAMP WITHOUT TIME ZONE,
    p_yolcuad VARCHAR,
    p_yolcusoyad VARCHAR,
    p_yolcutelefon VARCHAR
) 
RETURNS TEXT
AS 
$$
DECLARE
    v_alinabilir_koltuk INTEGER;
    v_son_koltuk INTEGER;
    v_koltuk_bilgisi TEXT;
BEGIN
    -- Seferdeki kalan alınabilir koltuk sayısına bakıyoruz
    SELECT alinabilirkoltuksayisi INTO v_alinabilir_koltuk FROM seferler_ucak 
    WHERE ucakseferno = p_ucakseferno;

    -- Eğer alınabilir koltuk sayısı 0 ise işlem yapmayacak ve bir exception fırlatacak
    IF v_alinabilir_koltuk <= 0 THEN
        RAISE EXCEPTION 'Bu uçuş için boş koltuk bulunmamaktadır, bilet alınamaz.';
    END IF;

    -- Bu sefer için en son eklenen koltuk numarasını buluyoruz ki yeni eklenecek koltuğun numarasını bulalım
    SELECT COALESCE(MAX(koltukno), 0)
    INTO v_son_koltuk
    FROM biletler_ucak
    WHERE ucakseferno = p_ucakseferno;

    -- Yeni koltuk numarasını hesaplıyoruz
    v_son_koltuk := v_son_koltuk + 1;

    -- Bileti ekliyoruz
    INSERT INTO biletler_ucak (kullaniciid, ucakseferno, koltukno, satistarihi, yolcuad, yolcusoyad, yolcutelefon)
    VALUES (p_kullaniciid, p_ucakseferno, v_son_koltuk, p_satistarihi::DATE, p_yolcuad, p_yolcusoyad, p_yolcutelefon);

    -- Sonuç mesacı oluşturuyoruz
    v_koltuk_bilgisi := FORMAT('Bilet başarıyla alındı! Koltuk No: %s', v_son_koltuk);

    -- Başarı mesajını döndürüyoruz
    RETURN v_koltuk_bilgisi;
END;
$$ 
LANGUAGE plpgsql;