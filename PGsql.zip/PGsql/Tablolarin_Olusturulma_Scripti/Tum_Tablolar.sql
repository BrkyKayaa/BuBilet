CREATE TABLE Oteller(
	otelID VARCHAR(6) PRIMARY KEY NOT NULL,
	otelAd VARCHAR(20) NOT NULL,
	otelAdres TEXT NOT NULL,
	toplamOdaSayisi INTEGER NOT NULL,
	alinabilirOdaSayisi INTEGER NOT NULL
);

CREATE TABLE Kullanicilar(
	kullaniciID SERIAL PRIMARY KEY NOT NULL,
	kullaniciAd VARCHAR(15) NOT NULL,
	kullaniciSoyad VARCHAR(15) NOT NULL,
	eposta VARCHAR(30) NOT NULL,
	kullaniciSifre VARCHAR(20) NOT NULL,
	kullaniciTel VARCHAR(11) NOT NULL,
	kullaniciTuru VARCHAR(10) NOT NULL
);


CREATE TABLE Rezervasyonlar(
	rezervasyonID VARCHAR(7) PRIMARY KEY NOT NULL,
	kullaniciID INTEGER NOT NULL,
	otelID VARCHAR(6) NOT NULL,
	rezervasyonTarihi DATE NOT NULL,
	rezervasyonDurum BIT NOT NULL,
	odaNumarasi INTEGER NOT NULL,
	CONSTRAINT fk_otelID FOREIGN KEY (otelID) REFERENCES Oteller (otelID),
	CONSTRAINT fk_kullaniciID FOREIGN KEY (kullaniciID) REFERENCES kullanicilar(kullaniciID)
);


CREATE TABLE Suruculer(
	surucuID SERIAL PRIMARY KEY NOT NULL,
	surucuAd VARCHAR(15) NOT NULL,
	surucuSoyad VARCHAR(15) NOT NULL,
	surucuTel VARCHAR(11) NOT NULL
);



CREATE TABLE Otobus_Suruculeri(
	Suruculer_surucuID INTEGER NOT NULL,
	Otobusler_surucuID INTEGER NOT NULL
);


CREATE TABLE Otobusler(
	otobusID VARCHAR(6) PRIMARY KEY NOT NULL,
	surucuID INTEGER,
	plaka VARCHAR(8) NOT NULL,
	marka VARCHAR(10) NOT NULL,
	model VARCHAR(10) NOT NULL,
	toplamKoltukSayisi INTEGER NOT NULL
);

CREATE TABLE Seferler_Otobus(
	otobusSeferNo VARCHAR(8) PRIMARY KEY NOT NULL,
	kalkisYeri VARCHAR(15) NOT NULL,
	varisYeri VARCHAR(15) NOT NULL,
	tarih DATE NOT NULL,
	sure TIMESTAMP WITHOUT TIME ZONE NOT NULL,
	fiyat INTEGER NOT NULL,
	otobusID VARCHAR(6) NOT NULL,
	alinabilirkoltuksayisi INT NOT NULL,
	CONSTRAINT fk_otobusID FOREIGN KEY (otobusID) REFERENCES Otobusler (otobusID)
);

CREATE TABLE Biletler_Otobus(
	PNR_Otobus VARCHAR(12) PRIMARY KEY NOT NULL,
	kullaniciID INTEGER NOT NULL,
	otobusSeferNo VARCHAR(8) NOT NULL,
	koltukNo INTEGER NOT NULL,
	satisTarihi DATE NOT NULL,
	yolcuad VARCHAR(15) NOT NULL,
	yolcusoyad VARCHAR(15) NOT NULL,
	tolcutelefon VARCHAR(11) NOT NULL,
	CONSTRAINT fk_kullaniciID FOREIGN KEY (kullaniciID) REFERENCES Kullanicilar (kullaniciID),
	CONSTRAINT fk_otobusSeferNo FOREIGN KEY (otobusSeferNo) REFERENCES Seferler_Otobus (otobusSeferNo)
);

CREATE TABLE Ucaklar(
	ucakID VARCHAR(6) PRIMARY KEY NOT NULL,
	toplamKoltukSayisi INTEGER NOT NULL
);

CREATE TABLE Seferler_Ucak(
	ucakSeferNo VARCHAR(8) PRIMARY KEY NOT NULL,
	kalkisYeri VARCHAR(15) NOT NULL,
	varisYeri VARCHAR(15) NOT NULL,
	tarih DATE NOT NULL,
	sure TIMESTAMP NOT NULL,
	fiyat INTEGER NOT NULL,
	ucakID VARCHAR(6) NOT NULL,
	alinabilirkoltuksayisi INT NOT NULL,
	CONSTRAINT fk_ucakID FOREIGN KEY (ucakID) REFERENCES Ucaklar (ucakID)
);


CREATE TABLE Biletler_Ucak(
	PNR_Ucak VARCHAR(12) PRIMARY KEY NOT NULL,
	kullaniciID INTEGER NOT NULL,
	ucakSeferNo VARCHAR(8) NOT NULL,
	koltukNo INTEGER NOT NULL,
	satisTarihi DATE NOT NULL,
	yolcuad VARCHAR(15) NOT NULL,
	yolcusoyad VARCHAR(15) NOT NULL,
	yolcutelefon VARCHAR(11) NOT NULL,
	CONSTRAINT fk_kullaniciID FOREIGN KEY (kullaniciID) REFERENCES Kullanicilar (kullaniciID),
	CONSTRAINT fk_ucakSeferNo FOREIGN KEY (ucakSeferNo) REFERENCES Seferler_Ucak (ucakSeferNo)
);

