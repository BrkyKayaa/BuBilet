/* ucaklar tablosundaki ucakID değeri için sequence */
CREATE SEQUENCE ucak_id_sequence START 1 INCREMENT 1 MINVALUE 1 MAXVALUE 99999;

/* ucakID değerini otomatik belirleyecek fonksiyonu tanımlıyoruz */
CREATE OR REPLACE FUNCTION generate_ucak_id() RETURNS TRIGGER
AS
$$
BEGIN
	NEW.ucakID := 'P' || LPAD(NEXTVAL('ucak_id_sequence')::TEXT, 5, '0');
	RETURN NEW;
END;
$$
LANGUAGE plpgsql;

/* ucaklar tablosuna yeni veri eklendiğinde çalışacak trigger'i tanımlıyoruz. */
CREATE TRIGGER ucak_id_trigger BEFORE INSERT ON ucaklar FOR EACH ROW 
WHEN (NEW.ucakID IS NULL)
	EXECUTE FUNCTION generate_ucak_id();


/* ucaklar tablosuna veri eklemek icin prosedür */
CREATE OR REPLACE PROCEDURE insert_ucaklar(
    p_toplamkoltuksayisi INTEGER
)
AS
$$
BEGIN
    INSERT INTO ucaklar (toplamkoltuksayisi) VALUES (p_toplamkoltuksayisi);

    RAISE NOTICE 'Yeni uçak eklendi';
END;
$$
LANGUAGE plpgsql;

/* ucaklar tablosundaki bir satırı güncellerken çalışacak prosedür */
CREATE OR REPLACE PROCEDURE update_ucaklar(
	IN p_ucakid VARCHAR,
	IN p_toplamkoltuksayisi INTEGER
)
AS
$$
BEGIN
	UPDATE ucaklar SET
		toplamkoltuksayisi = p_toplamkoltuksayisi
	WHERE ucakid = p_ucakid;

	RAISE NOTICE 'Uçak: % güncellendi.',p_ucakid;
END;
$$
LANGUAGE plpgsql;

/* ucaklar tablosundan veri silineceği zaman çalışacak prosedür */
CREATE OR REPLACE PROCEDURE delete_ucaklar(
	IN p_ucakid VARCHAR
)
AS
$$
BEGIN
	DELETE FROM ucaklar WHERE ucakid = p_ucakid;

	RAISE NOTICE 'Uçak silindi.';
END;
$$
LANGUAGE plpgsql;
	