/* kullanicilar tablosuna kayıt olunacağı zaman çalışacak prosedür */
CREATE OR REPLACE PROCEDURE kayit_ol_kullanicilar(
	IN p_kullaniciad VARCHAR,
	IN p_kullanicisoyad VARCHAR,
	IN p_eposta VARCHAR,
	IN p_kullanicisifre VARCHAR,
	IN p_kullanicitel VARCHAR
)
AS
$$
BEGIN
	INSERT INTO kullanicilar (kullaniciad, kullanicisoyad, eposta, kullanicisifre, kullanicitel, kullanicituru)
	VALUES (p_kullaniciad, p_kullanicisoyad, p_eposta, p_kullanicisifre, p_kullanicitel, 'Musteri');

	RAISE NOTICE 'Kayıt oldunuz. Kullanici adınız ve şifreniz ile giriş yapabilirsiniz.';
END;
$$
LANGUAGE plpgsql;

