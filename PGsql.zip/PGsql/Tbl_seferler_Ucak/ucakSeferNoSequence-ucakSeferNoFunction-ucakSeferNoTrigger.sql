/* seferler_ucak tablosundaki ucakseferno değeri için sequence */
CREATE SEQUENCE ucak_sefer_no_sequence START 1 INCREMENT 1 MINVALUE 1 MAXVALUE 999999;

/* ucakSeferNo değerini otomatik belirleyecek fonksiyonu tanımlıyoruz */
CREATE OR REPLACE FUNCTION generate_ucak_sefer_no() RETURNS TRIGGER
AS
$$
BEGIN
	NEW.ucakSeferNo := 'PT' || LPAD(NEXTVAL('ucak_sefer_no_sequence')::TEXT, 6, '0');
	RETURN NEW;
END;
$$
LANGUAGE plpgsql;

/* seferler_ucak tablosuna yeni veri eklendiğinde çalışacak trigger'i tanımlıyoruz. */
CREATE TRIGGER ucak_sefer_no_trigger BEFORE INSERT ON seferler_ucak FOR EACH ROW 
WHEN (NEW.ucakSeferNo IS NULL)
	EXECUTE FUNCTION generate_ucak_sefer_no();


/* seferler_ucak tablosuna yeni veri eklendiğinde ucakID değerine göre alinabilirKoltukSayisi'ni
ucaklar tablosundaki toplamKoltukSayisi'na eşitleyen trigger */

/* Öncelikle alinabilirKoltukSayisini generate edecek fonksiyonu tanımlıyoruz */
CREATE OR REPLACE FUNCTION generate_alinabilirKoltukSayisi_ucaklar() RETURNS TRIGGER 
AS 
$$
BEGIN
  SELECT toplamkoltuksayisi INTO NEW.alinabilirkoltuksayisi FROM ucaklar WHERE ucakid = NEW.ucakid;

  RETURN NEW;
END;
$$ 
LANGUAGE plpgsql;

/* seferler_ucak tablosuna kayıt eklendiğinde alinabilirKoltukSayisini işleyen trigger'i tanımlıyoruz */
CREATE TRIGGER set_alinabilirKoltukSayisiTrigger BEFORE INSERT ON seferler_ucak
FOR EACH ROW EXECUTE FUNCTION generate_alinabilirKoltukSayisi_ucaklar();



/* seferler_ucak tablosuna insert işlemini yapan stored procedure */
CREATE OR REPLACE PROCEDURE insert_seferler_ucak(
    p_kalkisyeri VARCHAR,
    p_varisyeri VARCHAR,
    p_tarih DATE,
    p_sure TIMESTAMP WITHOUT TIME ZONE,
    p_fiyat INTEGER,
    p_ucakid VARCHAR
)
AS 
$$
BEGIN
    INSERT INTO seferler_ucak (kalkisyeri, varisyeri, tarih, sure, fiyat, ucakid)
    VALUES (p_kalkisyeri, p_varisyeri, p_tarih, p_sure, p_fiyat, p_ucakid);

    RAISE NOTICE 'Yeni sefer başarıyla eklendi.';
END;
$$
LANGUAGE plpgsql;


/* seferler_ucak tablosunda update sorgusu kullanan prosedür */
CREATE OR REPLACE PROCEDURE update_seferler_ucak(
    p_ucakseferno VARCHAR,
    p_kalkisyeri VARCHAR,
    p_varisyeri VARCHAR,
    p_tarih DATE,
    p_sure TIMESTAMP,
    p_fiyat INTEGER,
    p_ucakid VARCHAR,
    p_alinabilirkoltuksayisi INTEGER
)
AS 
$$
BEGIN
    UPDATE seferler_ucak SET 
        kalkisyeri = p_kalkisyeri,
        varisyeri = p_varisyeri,
        tarih = p_tarih,
        sure = p_sure,
        fiyat = p_fiyat,
        ucakid = p_ucakid,
        alinabilirkoltuksayisi = p_alinabilirkoltuksayisi
    WHERE ucakseferno = p_ucakseferno;

    RAISE NOTICE 'Sefer % başarıyla güncellendi.',p_ucakseferno;
END;
$$
LANGUAGE plpgsql;

/* seferler_ucak tablosundan sefer silme sırasında çalışacak prosedür */
CREATE OR REPLACE PROCEDURE delete_seferler_ucak(
    p_ucakseferno VARCHAR
)
AS 
$$
BEGIN
    DELETE FROM seferler_ucak WHERE ucakseferno = p_ucakseferno;

    -- Eğer kayıt bulunamazsa bilgilendirme mesajı gösteriyoruz --
    IF NOT FOUND THEN
        RAISE NOTICE 'Silinmek istenen kayıt bulunamadı: %', p_ucakseferno;
    ELSE
        RAISE NOTICE 'Sefer başarıyla silindi: %', p_ucakseferno;
    END IF;
END;
$$
LANGUAGE plpgsql;