/* rezervasyonID değeri için sequence tanımlıyoruz. */
CREATE SEQUENCE rezervasyon_id_sequence START 1 INCREMENT 1 MINVALUE 1 MAXVALUE 999999;

/* rezervasyonID değerini otomatik belirleyecek fonksiyonu tanımlıyoruz */
CREATE OR REPLACE FUNCTION generate_rezervasyon_id() RETURNS TRIGGER
AS
$$
BEGIN
	NEW.rezervasyonID := 'R' || LPAD(NEXTVAL('rezervasyon_id_sequence')::TEXT,6,'0');
	RETURN NEW;
END;
$$
LANGUAGE plpgsql;

/* Otobüsler tablosuna yeni veri eklendiğinde çalışacak trigger'i tanımlıyoruz. */
CREATE TRIGGER rezervasyon_id_trigger BEFORE INSERT ON rezervasyonlar FOR EACH ROW 
WHEN (NEW.rezervasyonID IS NULL)
	EXECUTE FUNCTION generate_rezervasyon_id();


/* Rezervasyon durumu için bir trigger yazılacak, rezervasyon tarihi geçince rezervasyon durumu false olacak */

