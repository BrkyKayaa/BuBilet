/* seferler_Otobus tablosu için otobusSeferNo değeri için sequence */
CREATE SEQUENCE otobus_sefer_no_sequence START 1 INCREMENT 1 MINVALUE 1 MAXVALUE 999999;

/* otobusSeferNo değerini otomatik belirleyecek fonksiyonu tanımlıyoruz */
CREATE OR REPLACE FUNCTION generate_otobus_sefer_no() RETURNS TRIGGER
AS
$$
BEGIN
	NEW.otobusseferno := 'BT' || LPAD(NEXTVAL('otobus_sefer_no_sequence')::TEXT, 6, '0');
	RETURN NEW;
END;
$$
LANGUAGE plpgsql;

/* seferler_Otobus tablosuna yeni veri eklendiğinde çalışacak trigger'i tanımlıyoruz. */
CREATE TRIGGER otobus_sefer_no_trigger BEFORE INSERT ON seferler_otobus FOR EACH ROW 
WHEN (NEW.otobusSeferNo IS NULL)
	EXECUTE FUNCTION generate_otobus_sefer_no();


/* seferler_Otobus tablosuna yeni veri eklendiğinde alinabilirKoltukSayisi değerini otobusler tablosundaki
toplamKoltukSayisi'na eşitleyen trigger'i tanımlıyoruz. */

CREATE OR REPLACE FUNCTION generate_alinabilirKoltukSayisi_otobusler() RETURNS TRIGGER 
AS 
$$
BEGIN
  SELECT toplamkoltuksayisi INTO NEW.alinabilirkoltuksayisi FROM otobusler WHERE otobusid = NEW.otobusid;

  RETURN NEW;
END;
$$ 
LANGUAGE plpgsql;

/* seferler_otobus tablosuna kayıt eklendiğinde alinabilirKoltukSayisini işleyen trigger'i tanımlıyoruz */
CREATE TRIGGER set_alinabilirKoltukSayisiTrigger BEFORE INSERT ON seferler_otobus
FOR EACH ROW EXECUTE FUNCTION generate_alinabilirKoltukSayisi_otobusler();


/* seferler_otobus tablosunda bir satırı güncellemek için prosedür tanımlıyoruz */
CREATE OR REPLACE PROCEDURE update_sefer_otobus_procedure(
    IN p_otobusseferno VARCHAR,
    IN p_kalkisyeri VARCHAR,
    IN p_varisyeri VARCHAR,
    IN p_tarih DATE,
    IN p_sure TIMESTAMP WITHOUT TIME ZONE,
    IN p_fiyat INTEGER,
    IN p_otobusid VARCHAR,
    IN p_alinabilirkoltuksayisi INTEGER
)
AS 
$$
BEGIN
    UPDATE seferler_otobus SET 
		kalkisyeri = p_kalkisyeri,
        varisyeri = p_varisyeri,
        tarih = p_tarih,
        sure = p_sure,
        fiyat = p_fiyat,
        otobusid = p_otobusid,
        alinabilirkoltuksayisi = p_alinabilirkoltuksayisi
    WHERE otobusseferno = p_otobusseferno;
	
    -- Güncelleme sonrası bir mesaj gönderiyoruz --
    RAISE NOTICE 'Sefer % başarıyla güncellendi.', p_otobusseferno;
END;
$$
LANGUAGE plpgsql;
