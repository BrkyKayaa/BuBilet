/* biletler_Otobus tablosu için pnr_otobus değeri için sequence */
CREATE SEQUENCE pnr_otobus_sequence START 1 INCREMENT 1 MINVALUE 1 MAXVALUE 999999;

/* pnr_otobus değerini otomatik belirleyecek fonksiyonu tanımlıyoruz */
CREATE OR REPLACE FUNCTION generate_pnr_otobus() RETURNS TRIGGER
AS
$$
BEGIN
	NEW.pnr_otobus := 'PNR-BT' || LPAD(NEXTVAL('pnr_otobus_sequence')::TEXT, 6, '0');
	RETURN NEW;
END;
$$
LANGUAGE plpgsql;

/* biletler_otobus tablosuna yeni veri eklendiğinde çalışacak trigger'i tanımlıyoruz. */
CREATE TRIGGER pnr_otobus_trigger BEFORE INSERT ON biletler_otobus FOR EACH ROW 
WHEN (NEW.pnr_otobus IS NULL)
	EXECUTE FUNCTION generate_pnr_otobus();


/* biletler_otobus tablosuna yeni veri eklendiğinde seferler_otobus tablosundaki
alinabilirkoltuksayisi sütununu güncelleyen fonksiyon */
CREATE OR REPLACE FUNCTION update_alinabilirkoltuksayisi_seferler_otobus() RETURNS TRIGGER
AS
$$
BEGIN
	UPDATE seferler_otobus SET alinabilirkoltuksayisi = alinabilirkoltuksayisi - 1
	WHERE otobusseferno = NEW.otobusseferno;

	RETURN NEW;
END;
$$
LANGUAGE plpgsql;

/* biletler_otobus tablosuna veri eklendiğinde update_alinabilirkoltuksayisi() fonksiyonunu
çalıştıracak olan trigger */
CREATE TRIGGER update_seferler_otobus_Trigger AFTER INSERT ON biletler_otobus
FOR EACH ROW EXECUTE FUNCTION update_alinabilirkoltuksayisi_seferler_otobus();


/* biletler_otobus tablosuna veri kayıt edileceği zaman çalışacak olan prosedür */
CREATE OR REPLACE PROCEDURE insert_biletler_otobus(
	IN p_kullaniciid INTEGER,
	IN p_otobusseferno VARCHAR,
	IN p_koltukno INTEGER,
	IN p_satistarihi TIMESTAMP WITHOUT TIME ZONE,
	IN p_yolcuad VARCHAR,
	IN p_yolcusoyad VARCHAR,
	IN p_yolcutelefon VARCHAR
)
AS
$$
BEGIN
	INSERT INTO biletler_otobus (kullaniciid, otobusseferno, koltukno, satistarihi, yolcuad, yolcusoyad, yolcutelefon)
	VALUES (p_kullaniciid, p_otobusseferno, p_koltukno, p_satistarihi::DATE, p_yolcuad, p_yolcusoyad, p_yolcutelefon);

	RAISE NOTICE 'Bilet alındı. Sefer No: %, Koltuk No: %',p_otobusseferno, p_koltukno;
END;
$$
LANGUAGE plpgsql;
