/* Oteller Tablosunda ID Değeri İçin Sequence oluşturuyoruz. */

CREATE SEQUENCE otel_id_sequence START 1 INCREMENT 1 MINVALUE 1 MAXVALUE 99999;

/* OtelID kısmını düzenleyecek fonksiyonu oluşturuyoruz. */

CREATE OR REPLACE FUNCTION generate_otel_id() RETURNS TRIGGER
AS
$$
BEGIN
	NEW.otelID := 'H' || LPAD(NEXTVAL('otel_id_sequence')::TEXT,5,'0');
	RETURN NEW;
END;
$$
LANGUAGE plpgsql;

/* Her otel ekleme işleminden önce çalışacak olan otel_id_trigger oluşturulması */

CREATE TRIGGER otel_id_trigger BEFORE INSERT ON oteller FOR EACH ROW
WHEN (NEW.otelID IS NULL) EXECUTE FUNCTION generate_otel_id();




/* Yeni bir otel eklenmesi sırasında çalışacak fonksiyon ve triggerler */

CREATE OR REPLACE FUNCTION set_alinabilir_oda_sayisi() RETURNS TRIGGER
AS
$$
BEGIN
	IF NEW.alinabilirOdaSayisi IS NULL THEN
		NEW.alinabilirOdaSayisi := NEW.toplamOdaSayisi;
	END IF;
	RETURN NEW;
END;
$$
LANGUAGE plpgsql;

/* Ekleme işleminden önce çalışacak trigger */

CREATE TRIGGER trigger_set_alinabilir_oda_sayisi BEFORE INSERT ON Oteller FOR EACH ROW
EXECUTE FUNCTION set_alinabilir_oda_sayisi();


