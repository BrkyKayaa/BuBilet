/* Kullanıcının girdiği pnr değerine göre bilet bilgilerini bize veren fonksiyon kalkisyeri, varisyeri, tarih eksik*/
CREATE OR REPLACE FUNCTION pnr_bilgisine_gore_bilet_bul(p_pnr VARCHAR)
RETURNS TABLE (
    kullaniciid INTEGER,
    pnr VARCHAR,
    seferno VARCHAR,
    koltukno INTEGER,
    satistarihi DATE,
    yolcuad_gizli TEXT,
    yolcusoyad_gizli TEXT,
    yolcutelefon_gizli TEXT
) 
AS
$$
BEGIN
    -- Eğer PNR "PNR-BT" ile başlıyorsa, biletler_otobus tablosundan sorgula
    IF p_pnr LIKE 'PNR-BT%' THEN
        RETURN QUERY 
        SELECT 
            bo.kullaniciid, 
            bo.pnr_otobus AS pnr, 
            bo.otobusseferno AS seferno, 
            bo.koltukno, 
            bo.satistarihi,
            -- Yolcu Adı'nın yalnızca ilk iki harfi görünür
            CONCAT(SUBSTRING(bo.yolcuad, 1, 2), REPEAT('*', GREATEST(LENGTH(bo.yolcuad) - 2, 0))) AS yolcuad_gizli,
            -- Yolcu Soyadı'nın yalnızca ilk iki harfi görünür
            CONCAT(SUBSTRING(bo.yolcusoyad, 1, 2), REPEAT('*', GREATEST(LENGTH(bo.yolcusoyad) - 2, 0))) AS yolcusoyad_gizli,
            -- Telefon numarasının yalnızca son dört hanesi görünür
            CONCAT(SUBSTRING(bo.yolcutelefon, 1, 6), REPEAT('*', GREATEST(LENGTH(bo.yolcutelefon) - 6, 0))) AS yolcutelefon_gizli
        FROM biletler_otobus bo
        WHERE bo.pnr_otobus = p_pnr;

    -- Eğer PNR "PNR-PT" ile başlıyorsa, biletler_ucak tablosundan sorgula
    ELSIF p_pnr LIKE 'PNR-PT%' THEN
        RETURN QUERY 
        SELECT 
            bu.kullaniciid, 
            bu.pnr_ucak AS pnr, 
            bu.ucakseferno AS seferno, 
            bu.koltukno, 
            bu.satistarihi,
            -- Yolcu Adı'nın yalnızca ilk iki harfi görünür
            CONCAT(SUBSTRING(bu.yolcuad, 1, 2), REPEAT('*', GREATEST(LENGTH(bu.yolcuad) - 2, 0))) AS yolcuad_gizli,
            -- Yolcu Soyadı'nın yalnızca ilk iki harfi görünür
            CONCAT(SUBSTRING(bu.yolcusoyad, 1, 2), REPEAT('*', GREATEST(LENGTH(bu.yolcusoyad) - 2, 0))) AS yolcusoyad_gizli,
            -- Telefon numarasının yalnızca son dört hanesi görünür
            CONCAT(SUBSTRING(bu.yolcutelefon, 1, 6), REPEAT('*', GREATEST(LENGTH(bu.yolcutelefon) - 6, 0))) AS yolcutelefon_gizli
        FROM biletler_ucak bu
        WHERE bu.pnr_ucak = p_pnr;

    -- Eğer PNR formatı geçersizse hata döndür
    ELSE
        RAISE EXCEPTION 'Geçersiz PNR formatı: %', p_pnr;
    END IF;
END;
$$
LANGUAGE plpgsql;


/* kalkisyeri, varisyeri ve tarih eklenmiş hâli */
CREATE OR REPLACE FUNCTION pnr_bilgisine_gore_bilet(p_pnr VARCHAR)
RETURNS TABLE (
    kullaniciid INTEGER,
    pnr VARCHAR,
    seferno VARCHAR,
    koltukno INTEGER,
    satistarihi DATE,
    yolcuad_gizli TEXT,
    yolcusoyad_gizli TEXT,
    yolcutelefon_gizli TEXT,
    kalkisyeri VARCHAR,
    varisyeri VARCHAR,
    tarih DATE
) 
AS
$$
BEGIN
    -- Eğer PNR "PNR-BT" ile başlıyorsa, biletler_otobus ve seferler_otobus tablolarından sorgula
    IF p_pnr LIKE 'PNR-BT%' THEN
        RETURN QUERY 
        SELECT 
            bo.kullaniciid, 
            bo.pnr_otobus AS pnr, 
            bo.otobusseferno AS seferno, 
            bo.koltukno, 
            bo.satistarihi,
            -- Yolcu Adı'nın yalnızca ilk iki harfi görünür
            CONCAT(SUBSTRING(bo.yolcuad, 1, 2), REPEAT('*', GREATEST(LENGTH(bo.yolcuad) - 2, 0))) AS yolcuad_gizli,
            -- Yolcu Soyadı'nın yalnızca ilk iki harfi görünür
            CONCAT(SUBSTRING(bo.yolcusoyad, 1, 2), REPEAT('*', GREATEST(LENGTH(bo.yolcusoyad) - 2, 0))) AS yolcusoyad_gizli,
            -- Telefon numarasının yalnızca son dört hanesi görünür
            CONCAT(SUBSTRING(bo.yolcutelefon, 1, 6), REPEAT('*', GREATEST(LENGTH(bo.yolcutelefon) - 6, 0))) AS yolcutelefon_gizli,
            so.kalkisyeri,
            so.varisyeri,
            so.tarih
        FROM biletler_otobus bo
        LEFT JOIN seferler_otobus so ON bo.otobusseferno = so.otobusseferno
        WHERE bo.pnr_otobus = p_pnr;

    -- Eğer PNR "PNR-PT" ile başlıyorsa, biletler_ucak tablosundan sorgula (eski haliyle bırakılmıştır)
    ELSIF p_pnr LIKE 'PNR-PT%' THEN
        RETURN QUERY 
        SELECT 
            bu.kullaniciid, 
            bu.pnr_ucak AS pnr, 
            bu.ucakseferno AS seferno, 
            bu.koltukno, 
            bu.satistarihi,
            -- Yolcu Adı'nın yalnızca ilk iki harfi görünür
            CONCAT(SUBSTRING(bu.yolcuad, 1, 2), REPEAT('*', GREATEST(LENGTH(bu.yolcuad) - 2, 0))) AS yolcuad_gizli,
            -- Yolcu Soyadı'nın yalnızca ilk iki harfi görünür
            CONCAT(SUBSTRING(bu.yolcusoyad, 1, 2), REPEAT('*', GREATEST(LENGTH(bu.yolcusoyad) - 2, 0))) AS yolcusoyad_gizli,
            -- Telefon numarasının yalnızca son dört hanesi görünür
            CONCAT(SUBSTRING(bu.yolcutelefon, 1, 6), REPEAT('*', GREATEST(LENGTH(bu.yolcutelefon) - 6, 0))) AS yolcutelefon_gizli,
            su.kalkisyeri,
            su.varisyeri,
            su.tarih
        FROM biletler_ucak bu LEFT JOIN seferler_ucak su ON bu.ucakseferno = su.ucakseferno
        WHERE bu.pnr_ucak = p_pnr;

    -- Eğer PNR formatı geçersizse hata döndür
    ELSE
        RAISE EXCEPTION 'Geçersiz PNR formatı: %', p_pnr;
    END IF;
END;
$$
LANGUAGE plpgsql;
