/* Otobüs Seferlerini Listelemek İçin Fonksiyon Kullanıyoruz. SİLDİM SİLDİM YAZDIM OROSPU EVLADI FONKSİYON*/

DROP FUNCTION ListOtobusSeferler;


CREATE OR REPLACE FUNCTION ListOtobusSeferler(
    IN p_hedefTarih DATE,
	IN p_kalkisYeri VARCHAR,
	IN p_varisYeri VARCHAR
)RETURNS TABLE (
    seferNo VARCHAR,
    kalkisYeri VARCHAR,
    varisYeri VARCHAR,
    tarih DATE,
    sure TIMESTAMP WITHOUT TIME ZONE,
    fiyat INTEGER,
    otobusID VARCHAR
)
LANGUAGE plpgsql
AS
$$
BEGIN
    RETURN QUERY
    SELECT 
		so.otobusSeferNo,
		so.kalkisYeri,
		so.varisYeri,
		so.tarih,
		so.sure,
		so.fiyat,
		so.otobusID
	FROM seferler_otobus AS so WHERE so.tarih = p_hedefTarih::DATE AND so.kalkisYeri = p_kalkisYeri
	AND so.varisYeri = p_varisYeri;
END;
$$;