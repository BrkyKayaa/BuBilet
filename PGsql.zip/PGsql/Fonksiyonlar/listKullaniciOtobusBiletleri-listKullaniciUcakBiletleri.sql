/* kullaniciid degerine gore kullanicinin biletlerini listeleyen fonksiyonlar */
CREATE OR REPLACE FUNCTION list_kullanici_otobus_biletleri(
	IN p_kullaniciid INTEGER
)
RETURNS TABLE (
	pnr_otobus VARCHAR,
	koltukno INTEGER,
	satistarihi DATE,
	yolcuad VARCHAR,
	yolcusoyad VARCHAR,
	yolcutelefon VARCHAR,
	kalkisyeri VARCHAR,
	varisyeri VARCHAR,
	sefertarihi DATE
)
AS
$$
BEGIN
	RETURN QUERY
	SELECT bo.pnr_otobus, 
	bo.koltukno, 
	bo.satistarihi, 
	bo.yolcuad, 
	bo.yolcusoyad, 
	bo.yolcutelefon, 
	so.kalkisyeri,
	so.varisyeri,
	so.tarih AS sefertarihi
	FROM biletler_otobus bo LEFT JOIN seferler_otobus so ON bo.otobusseferno = so.otobusseferno
	WHERE bo.kullaniciid = p_kullaniciid;
END;
$$
LANGUAGE plpgsql;



/* kullaniciid değerine göre kullanıcının uçak biletlerini listeleyen fonksiyon */
CREATE OR REPLACE FUNCTION list_kullanici_ucak_biletleri(
	IN p_kullaniciid INTEGER
)
RETURNS TABLE (
	pnr_ucak VARCHAR,
	koltukno INTEGER,
	satistarihi DATE,
	yolcuad VARCHAR,
	yolcusoyad VARCHAR,
	yolcutelefon VARCHAR,
	kalkisyeri VARCHAR,
	varisyeri VARCHAR,
	sefertarihi DATE
)
AS
$$
BEGIN
	RETURN QUERY
	SELECT bu.pnr_ucak, 
	bu.koltukno, 
	bu.satistarihi, 
	bu.yolcuad, 
	bu.yolcusoyad, 
	bu.yolcutelefon, 
	su.kalkisyeri,
	su.varisyeri,
	su.tarih AS sefertarihi
	FROM biletler_ucak bu LEFT JOIN seferler_ucak su ON bu.ucakseferno = su.ucakseferno
	WHERE bu.kullaniciid = p_kullaniciid;
END;
$$
LANGUAGE plpgsql;

	