/* otobusID değeri için sequence tanımlıyoruz. */
CREATE SEQUENCE otobus_id_sequence START 1 INCREMENT 1 MINVALUE 1 MAXVALUE 99999;

/* otobusID değerini otomatik belirleyecek fonksiyonu tanımlıyoruz */
CREATE OR REPLACE FUNCTION generate_otobus_id() RETURNS TRIGGER
AS
$$
BEGIN
	NEW.otobusID := 'B' || LPAD(NEXTVAL('otobus_id_sequence')::TEXT,5,'0');
	RETURN NEW;
END;
$$
LANGUAGE plpgsql;

/* Otobüsler tablosuna yeni veri eklendiğinde çalışacak trigger'i tanımlıyoruz. */
CREATE TRIGGER otobus_id_trigger BEFORE INSERT ON otobusler FOR EACH ROW WHEN (NEW.otobusID IS NULL)
	EXECUTE FUNCTION generate_otobus_id();


/* Otobüsler tablosuna veri eklenmek istendiğinde çalışacak stored procedure */
CREATE OR REPLACE PROCEDURE otobus_ekle_procedure(
    p_surucuid INTEGER,
    p_plaka VARCHAR,
    p_marka VARCHAR,
    p_model VARCHAR,
    p_toplamkoltuksayisi INTEGER
)
AS
$$
BEGIN
    INSERT INTO otobusler (surucuid, plaka, marka, model, toplamkoltuksayisi)
    VALUES (p_surucuid, p_plaka, p_marka, p_model, p_toplamkoltuksayisi);
    
    -- Bir bilgilendirme mesajı gönderiyoruz --
    RAISE NOTICE 'Otobüs başarıyla eklendi.';
END;
$$
LANGUAGE plpgsql;

/* Otobüsler tablosunda veri güncellenecekse çalışacak prosedür */
CREATE OR REPLACE PROCEDURE otobus_guncelle_procedure(
    p_otobusid VARCHAR,              
    p_surucuid INTEGER DEFAULT NULL, 
    p_plaka VARCHAR DEFAULT NULL,   
    p_marka VARCHAR DEFAULT NULL,    
    p_model VARCHAR DEFAULT NULL,    
    p_toplamkoltuksayisi INTEGER DEFAULT NULL
)
AS
$$
BEGIN
    UPDATE otobusler SET 
        surucuid = COALESCE(p_surucuid, surucuid), -- COALESCE fonksiyonu girilen değer NULL'se sütunu değiştirmez --
        plaka = COALESCE(p_plaka, plaka),
        marka = COALESCE(p_marka, marka),
        model = COALESCE(p_model, model),
        toplamkoltuksayisi = COALESCE(p_toplamkoltuksayisi, toplamkoltuksayisi)
    WHERE otobusid = p_otobusid;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Belirtilen otobusid % ile kayıt bulunamadı.', p_otobusid;
    ELSE
        RAISE NOTICE 'Otobüs % başarıyla güncellendi.', p_otobusid;
    END IF;
END;
$$
LANGUAGE plpgsql;


/* Silme işleminde çalışacak olan procedure */
CREATE OR REPLACE PROCEDURE otobus_sil_procedure(
    p_otobusid VARCHAR
)
AS
$$
BEGIN
    DELETE FROM otobusler WHERE otobusid = p_otobusid;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Belirtilen otobusid % ile kayıt bulunamadı.', p_otobusid;
    ELSE
        RAISE NOTICE 'Otobüs % başarıyla silindi.', p_otobusid;
    END IF;
END;
$$
LANGUAGE plpgsql;